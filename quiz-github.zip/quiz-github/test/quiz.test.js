const { test } = require('node:test');
const assert = require('node:assert/strict');
const { io } = require('socket.io-client');
const { JSDOM, VirtualConsole } = require('jsdom');
const { PNG } = require('pngjs');
const jsQR = require('jsqr');
const { createQuizServer } = require('../server.cjs');
const questions = require('../questions');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(check, ms = 5000) {
  const end = Date.now() + ms;
  while (!check()) { if (Date.now() > end) throw new Error('Przekroczono czas oczekiwania'); await delay(15); }
}
async function setup(t, options = {}) {
  const quiz = createQuizServer({ countdownMs: 35, questionMs: 5000, ...options });
  await new Promise(resolve => quiz.server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${quiz.server.address().port}`, sockets = [];
  t.after(async () => { sockets.forEach(s => s.disconnect()); await quiz.close(); });
  const connect = async () => {
    const s = io(url, { forceNew: true, reconnection: false }); sockets.push(s);
    s.on('state', state => { s.latest = state; });
    await new Promise((resolve, reject) => { s.once('connect', resolve); s.once('connect_error', reject); }); return s;
  };
  return { quiz, url, connect };
}
const rpc = (s, event, data = {}) => new Promise((resolve, reject) => s.timeout(3000).emit(event, data, (err, r) => err ? reject(err) : resolve(r)));
test('HTTP, numeric PIN, decodable QR, room isolation and complete shared quiz', async t => {
  const { quiz, url, connect } = await setup(t, { publicUrl: 'https://quiz.example.test/' });
  for (const path of ['/', '/play', '/play/678-595', '/host', '/host.html', '/player.html', '/host.js', '/player.js', '/socket.io/socket.io.js', '/health']) {
    assert.equal((await fetch(url + path)).status, 200, path);
  }
  const host = await connect(), p1 = await connect(), p2 = await connect(), other = await connect();
  const room = await rpc(host, 'host:create'); assert.match(room.code, /^\d{6}$/);
  assert.equal(room.joinUrl, `https://quiz.example.test/play/${room.code}`);
  const png = PNG.sync.read(Buffer.from(room.qr.split(',')[1], 'base64'));
  assert.equal(jsQR(new Uint8ClampedArray(png.data), png.width, png.height).data, room.joinUrl);
  assert.ok((await rpc(host, 'host:create')).error);
  assert.ok((await rpc(host, 'host:start', { code: room.code })).error);
  assert.ok((await rpc(p1, 'player:join', null)).error);
  assert.ok((await rpc(p1, 'player:join', { code: '000000', name: 'A' })).error);
  const a = await rpc(p1, 'player:join', { code: room.code.slice(0, 3) + '-' + room.code.slice(3), name: 'Ala' }); assert.ok(a.ok);
  const b = await rpc(p2, 'player:join', { code: room.code, name: 'Olek' }); assert.ok(b.ok);
  assert.ok((await rpc(p1, 'player:join', { code: room.code, name: 'Duplikat' })).error);
  const separate = await rpc(other, 'host:create'); assert.notEqual(room.code, separate.code);
  assert.ok((await rpc(p1, 'host:start', { code: room.code })).error);
  assert.ok((await rpc(host, 'host:start', { code: room.code })).ok);
  assert.ok((await rpc(host, 'host:start', { code: room.code })).error);
  await until(() => p1.latest?.status === 'question');
  assert.equal(p1.latest.question.correct, undefined);
  assert.equal(other.latest.status, 'lobby');
  for (let i = 0; i < questions.length; i++) {
    await until(() => p1.latest?.status === 'question' && p1.latest.questionIndex === i);
    assert.ok((await rpc(p1, 'player:answer', { answer: null, questionIndex: i })).error);
    assert.ok((await rpc(p1, 'player:answer', { answer: 0, questionIndex: i - 1 })).error);
    assert.ok((await rpc(p1, 'player:answer', { answer: questions[i].correct, questionIndex: i })).ok);
    assert.ok((await rpc(p1, 'player:answer', { answer: 0, questionIndex: i })).error);
    assert.ok((await rpc(p2, 'player:answer', { answer: (questions[i].correct + 1) % 4, questionIndex: i })).ok);
    await until(() => p2.latest?.status === 'results' && p2.latest.questionIndex === i);
    assert.equal(p2.latest.results.leaderboard.find(p => p.id === a.id).score, (i + 1) * 1000);
    assert.ok((await rpc(host, 'host:next', { code: room.code, questionIndex: i })).ok);
    assert.ok((await rpc(host, 'host:next', { code: room.code, questionIndex: i })).error);
  }
  await until(() => p1.latest.status === 'finished');
  assert.equal(p1.latest.leaderboard[0].score, 10000); assert.equal(p1.latest.leaderboard[1].score, 0);
  assert.ok((await rpc(p1, 'player:leave')).ok);
  assert.ok((await rpc(p1, 'player:join', { code: separate.code, name: 'Nowy quiz' })).ok);
  assert.equal(quiz.rooms.size, 2);
});
test('local QR uses LAN address, reconnect preserves answers and host control, timer ends question', async t => {
  const { quiz, connect } = await setup(t, { lanAddress: '192.168.1.25', questionMs: 450, disconnectMs: 150 });
  let host = await connect(), player = await connect(); const hold = await connect();
  const room = await rpc(host, 'host:create'); assert.match(room.joinUrl, /^http:\/\/192\.168\.1\.25:/);
  const joined = await rpc(player, 'player:join', { code: room.code, name: 'Ala' });
  await rpc(hold, 'player:join', { code: room.code, name: 'Czeka' });
  await rpc(host, 'host:start', { code: room.code }); await until(() => player.latest?.status === 'question');
  await rpc(player, 'player:answer', { answer: questions[0].correct, questionIndex: 0 });
  player.disconnect(); await delay(25); player = await connect();
  const resumed = await rpc(player, 'player:join', { code: room.code, token: joined.token });
  assert.equal(resumed.id, joined.id); assert.equal(resumed.state.players.find(p => p.id === joined.id).answered, true);
  assert.ok((await rpc(player, 'player:answer', { answer: 1, questionIndex: 0 })).error);
  host.disconnect(); await delay(25); host = await connect();
  assert.ok((await rpc(host, 'host:resume', { code: room.code, token: 'wrong' })).error);
  assert.ok((await rpc(host, 'host:resume', { code: room.code, token: room.token })).ok);
  await until(() => player.latest.status === 'results');
  assert.equal(player.latest.results.leaderboard.find(p => p.id === joined.id).score, 1000);
  host.disconnect(); await until(() => quiz.rooms.size === 0);
});
test('real page scripts: create, join using PIN and QR path, answer, results, new game', async t => {
  const { url } = await setup(t, { countdownMs: 80 });
  const errors = [];
  async function page(path) {
    const console = new VirtualConsole(); console.on('jsdomError', err => errors.push(err.message));
    const dom = await JSDOM.fromURL(url + path, { resources: 'usable', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: console });
    t.after(() => { dom.window.eval('Quiz.socket.disconnect()'); dom.window.close(); });
    await new Promise(resolve => dom.window.addEventListener('load', resolve, { once: true }));
    return dom.window.document;
  }
  const landing = await page('/');
  assert.equal(landing.querySelector('#hostBtn').getAttribute('href'), '/host?autostart=1');
  assert.equal(landing.querySelector('#joinBtn').textContent, 'Dołącz');
  const host = await page('/host?autostart=1');
  await until(() => host.querySelector('#code').textContent.length > 0);
  const code = host.querySelector('#code').textContent; assert.match(code, /^\d{3}-\d{3}$/);
  const p1 = await page('/'), p2 = await page('/play/' + code.replace('-', ''));
  assert.equal(p2.querySelector('#roomCode').value, code);
  for (const [p, name] of [[p1, 'Ala'], [p2, 'Olek']]) {
    await until(() => !p.querySelector('#joinBtn').disabled);
    p.querySelector('#roomCode').value = code; p.querySelector('#name').value = name; p.querySelector('#joinBtn').click();
    await until(() => !p.querySelector('#wait').classList.contains('hidden'));
  }
  await until(() => host.querySelector('#count').textContent === '2');
  host.querySelector('#start').click();
  await until(() => p1.querySelectorAll('[data-answer]').length === 4 && p2.querySelectorAll('[data-answer]').length === 4);
  p1.querySelector('[data-answer="1"]').click(); p2.querySelector('[data-answer="0"]').click();
  await until(() => !host.querySelector('#results').classList.contains('hidden'));
  await until(() => p1.querySelector('#status').textContent.includes('1000'));
  assert.match(p2.querySelector('#question').textContent, /Poprawna odpowiedź/);
  host.querySelector('#next').click(); await until(() => p1.querySelector('#progress').textContent.includes('Pytanie 2'));
  const end = [...host.querySelectorAll('button')].find(b => b.textContent.includes('Zamknij quiz')); end.click();
  await until(() => !p1.querySelector('#join').classList.contains('hidden'));
  assert.equal(host.querySelector('#create').hidden, false);
  assert.deepEqual(errors, []);
});


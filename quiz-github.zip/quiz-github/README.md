# Quiz elektrownia — wspólna gra

## Wgranie na GitHub

Rozpakuj ZIP i wgraj zawartość folderu do repozytorium. `package.json`
i `server.cjs` muszą znajdować się w głównym katalogu repozytorium.
Zachowaj foldery `public` i `test`. Wgraj również `questions.js` oraz
`package-lock.json`. Sam serwer i package.json nie wystarczą.

## Uruchomienie

Wymagany Node.js 20 lub nowszy.

```sh
npm ci
npm start
```

Wszyscy otwierają http://localhost:3000. Prowadzący klika „Hostuj”, a uczestnicy wpisują kod i imię oraz klikają „Dołącz”.

Uczestnicy: http://localhost:3000 — na innym urządzeniu użyj adresu komputera
w sieci lokalnej zamiast localhost.

## Publikacja później na Render

Utwórz Web Service z tego repozytorium, z runtime Node.
Build Command: `npm ci --omit=dev`
Start Command: `npm start`
Health Check Path: `/health`

Ustaw `PUBLIC_URL` na rzeczywisty adres HTTPS przydzielony przez hosting,
bez ścieżki /host. Prowadzący otwiera stronę główną i klika „Hostuj”,
a uczniowie skanują QR lub wpisują kod na stronie głównej.

GitHub przechowuje kod. Samo wgranie plików na GitHub, również GitHub Pages,
nie uruchamia tego serwera multiplayer. HTTPS zapewnia hosting; nie jest to
osobny plik do pobrania.

## Zawartość

- `server.cjs` — serwer multiplayer.
- `package.json`, `package-lock.json` — konfiguracja i biblioteki.
- `questions.js` — pytania quizu.
- `public/host.html` — panel prowadzącego.
- `public/player.html` — dołączanie i ekran ucznia.
- `public/common.js`, `public/host.js`, `public/player.js` — obsługa stron.
- `test/quiz.test.js` — testy, uruchamiane przez `npm test` po `npm ci`.

Pokoje i punkty są przechowywane w pamięci serwera. Restart serwera kończy
aktywne gry. Używaj jednej instancji serwera.

Ta paczka zawiera quiz multiplayer. Nie zawiera wcześniejszej, osobnej gry,
której pliku nie dostarczono.

